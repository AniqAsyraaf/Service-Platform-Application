package com.example.projectandroid;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DatabaseHelper extends SQLiteOpenHelper {



    public static final String DATABASE_NAME="AppService.db";

    //service table
    public static final String TABLE_NAME_SERVICE="service_provider_table";
    public static final String col1_SERVICE="ID";
    public static final String col2_SERVICE="BUSINESS_NAME";
    public static final String col3_SERVICE="SERVICE_TYPE";
    public static final String col4_SERVICE="CONTACT_NUM";
    public static final String col5_SERVICE="EMAIL";
    public static final String col6_SERVICE="PASSWORD";

    //customer table
    public static final String TABLE_NAME_CUSTOMER="customer_table";
    public static final String col1_CUSTOMER="ID";
    public static final String col2_CUSTOMER="NAME";
    public static final String col3_CUSTOMER="CONTACT_NUM";
    public static final String col4_CUSTOMER="EMAIL";
    public static final String col5_CUSTOMER="PASSWORD";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);//create database

    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE "+TABLE_NAME_SERVICE+" (ID INTEGER PRIMARY KEY AUTOINCREMENT,BUSINESS_NAME TEXT,SERVICE_TYPE TEXT,CONTACT_NUM TEXT,EMAIL TEXT,PASSWORD TEXT)");
        db.execSQL("CREATE TABLE "+TABLE_NAME_CUSTOMER+" (ID INTEGER PRIMARY KEY AUTOINCREMENT,NAME TEXT,CONTACT_NUM TEXT,EMAIL TEXT,PASSWORD TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME_SERVICE);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME_CUSTOMER);
        onCreate(db);
    }


    //function service table

    public boolean insertDataService(String BUSINESS_NAME, String SERVICE_TYPE, String CONTACT_NUM, String EMAIL, String PASSWORD)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(DatabaseHelper.col2_SERVICE,BUSINESS_NAME);
        contentValues.put(DatabaseHelper.col3_SERVICE,SERVICE_TYPE);
        contentValues.put(DatabaseHelper.col4_SERVICE,CONTACT_NUM);
        contentValues.put(DatabaseHelper.col5_SERVICE,EMAIL);
        contentValues.put(DatabaseHelper.col6_SERVICE,PASSWORD);
        long result=db.insert(DatabaseHelper.TABLE_NAME_SERVICE,null,contentValues);
        if (result==-1)
            return false;
        else
            return true;
    }

    public Cursor getAllDataService()
    {
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor res=db.rawQuery("select * from "+DatabaseHelper.TABLE_NAME_SERVICE,null);
        return res;

    }

    public boolean updateDataService(String id, String BUSINESS_NAME, String SERVICE_TYPE, String CONTACT_NUM, String EMAIL, String PASSWORD)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(DatabaseHelper.col1_SERVICE,id);
        contentValues.put(DatabaseHelper.col2_SERVICE,BUSINESS_NAME);
        contentValues.put(DatabaseHelper.col3_SERVICE,SERVICE_TYPE);
        contentValues.put(DatabaseHelper.col4_SERVICE,CONTACT_NUM);
        contentValues.put(DatabaseHelper.col5_SERVICE,EMAIL);
        contentValues.put(DatabaseHelper.col6_SERVICE,PASSWORD);
        db.update(TABLE_NAME_SERVICE,contentValues,"ID=?",new String[] {id});
        return true;
    }

    public Integer deleteDataService(String id)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        return db.delete(TABLE_NAME_SERVICE,"ID=?",new String[] {id});
    }



    //function customer table


    public boolean insertDataCustomer(String NAME, String CONTACT_NUM, String EMAIL, String PASSWORD)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(DatabaseHelper.col2_CUSTOMER,NAME);
        contentValues.put(DatabaseHelper.col3_CUSTOMER,CONTACT_NUM);
        contentValues.put(DatabaseHelper.col4_CUSTOMER,EMAIL);
        contentValues.put(DatabaseHelper.col5_CUSTOMER,PASSWORD);
        long result=db.insert(DatabaseHelper.TABLE_NAME_CUSTOMER,null,contentValues);
        if (result==-1)
            return false;
        else
            return true;
    }

    public Cursor getAllDataCustomer()
    {
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor res=db.rawQuery("select * from "+DatabaseHelper.TABLE_NAME_CUSTOMER,null);
        return res;

    }

    public boolean updateDataCustomer(String id, String NAME, String CONTACT_NUM, String EMAIL, String PASSWORD)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(DatabaseHelper.col1_CUSTOMER,id);
        contentValues.put(DatabaseHelper.col2_CUSTOMER,NAME);
        contentValues.put(DatabaseHelper.col3_CUSTOMER,CONTACT_NUM);
        contentValues.put(DatabaseHelper.col4_CUSTOMER,EMAIL);
        contentValues.put(DatabaseHelper.col5_CUSTOMER,PASSWORD);
        db.update(TABLE_NAME_CUSTOMER,contentValues,"ID=?",new String[] {id});
        return true;
    }

    public Integer deleteDataCustomer(String id)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        return db.delete(TABLE_NAME_CUSTOMER,"ID=?",new String[] {id});
    }


}
