package com.example.projectandroid;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class CustomerMenu extends AppCompatActivity{


    String serviceType;
    TextView serviceTypeText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_menu);

        Bundle bundle=getIntent().getExtras();
        serviceType=bundle.getString("service_name");
        serviceTypeText=(TextView)findViewById(R.id.textView12);
        serviceTypeText.setText(serviceType);


    }




}
