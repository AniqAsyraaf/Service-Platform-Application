package com.example.projectandroid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class CustomerChooseServiceType extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_choose_service_type);

    }

    public void gotoElectrician(View v)
    {
        Intent intent=new Intent(CustomerChooseServiceType.this, CustomerMenu.class);
        intent.putExtra("service_name","Electrician");
        startActivity(intent);
    }
    public void gotoTechnician(View v)
    {
        Intent intent=new Intent(CustomerChooseServiceType.this, CustomerMenu.class);
        intent.putExtra("service_name","Technician");
        startActivity(intent);
    }
    public void gotoPlumber(View v)
    {
        Intent intent=new Intent(CustomerChooseServiceType.this, CustomerMenu.class);
        intent.putExtra("service_name","Plumber");
        startActivity(intent);
    }


}
