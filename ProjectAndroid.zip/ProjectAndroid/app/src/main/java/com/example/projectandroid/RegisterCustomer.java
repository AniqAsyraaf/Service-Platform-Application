package com.example.projectandroid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterCustomer extends AppCompatActivity {

    DatabaseHelper myDb;
    Button btnSubmitData;
    EditText editName;
    EditText editContactNumber;
    EditText editEmail;
    EditText editPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();


        setContentView(R.layout.register_customer);
        myDb=new DatabaseHelper(this);
        editName=(EditText)findViewById(R.id.editTextTextPersonName3);
        editContactNumber=(EditText)findViewById(R.id.editTextTextPersonName6);
        editEmail=(EditText)findViewById(R.id.editTextTextEmailAddress);
        editPassword=(EditText)findViewById(R.id.editTextTextPersonName8);
        btnSubmitData=(Button)findViewById(R.id.button);





        SubmitData();

    }

    public Boolean validate()
    {
        boolean result=false;

        String name=editName.getText().toString();
        String contactnum=editContactNumber.getText().toString();
        String email=editEmail.getText().toString();
        String password=editPassword.getText().toString();


        if(name.isEmpty()||contactnum.isEmpty()||email.isEmpty()||password.isEmpty())
        {
            String show="is empty";
            if(name.isEmpty())
            {
                String tempstring=" name ";
                show=tempstring+show;
            }
            if(contactnum.isEmpty())
            {
                String tempstring=" contact number ";
                show=tempstring+show;
            }
            if(email.isEmpty())
            {
                String tempstring=" email ";
                show=tempstring+show;
            }
            if(password.isEmpty())
            {
                String tempstring=" password ";
                show=tempstring+show;
            }
            Toast.makeText(RegisterCustomer.this, show, Toast.LENGTH_SHORT).show();
        }
        else
        {
            result=true;
        }

        return result;
    }

    public void SubmitData()
    {
        btnSubmitData.setOnClickListener(
                (view)->{
                    if(validate()) {
                        boolean isInserted = myDb.insertDataCustomer(editName.getText().toString(), editContactNumber.getText().toString(), editEmail.getText().toString(), editPassword.getText().toString());
                        if (isInserted)
                            Toast.makeText(RegisterCustomer.this, "Register Successful, Please Login", Toast.LENGTH_SHORT).show();
                        else
                            Toast.makeText(RegisterCustomer.this, "Register Not Successful", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(RegisterCustomer.this, LoginCustomer.class);
                        startActivity(intent);
                    }
                }
        );
    }

}