package com.example.projectandroid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class RegisterService extends AppCompatActivity {

    DatabaseHelper myDb;
    Button btnSubmitData;
    Spinner editServiceType,state,area;
    EditText editBusinessName;
    EditText editContactNumber;
    EditText editEmail;
    EditText editPassword;

    ArrayAdapter<String> dataAdapter;
    ArrayAdapter<String> myAdapterstate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();


        setContentView(R.layout.register_service);
        myDb=new DatabaseHelper(this);
        editBusinessName=(EditText)findViewById(R.id.editTextTextPersonName3);
        editServiceType=(Spinner)findViewById(R.id.spinner1);
        editContactNumber=(EditText)findViewById(R.id.editTextTextPersonName6);
        editEmail=(EditText)findViewById(R.id.editTextTextEmailAddress);
        editPassword=(EditText)findViewById(R.id.editTextTextPersonName8);
        btnSubmitData=(Button)findViewById(R.id.button);


        ArrayAdapter<String> myAdapter=new ArrayAdapter<>(RegisterService.this,android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.Service_Provider_Type));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        editServiceType.setAdapter(myAdapter);

        state=(Spinner)findViewById(R.id.state);
        area=(Spinner)findViewById(R.id.area);

        myAdapterstate=new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.state));
        myAdapterstate.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        state.setAdapter(myAdapterstate);


        state.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                if (position==0)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.None));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==1)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.Johor));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==2)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.Melaka));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==3)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.Negeri_Sembilan));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==4)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.Selangor));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==5)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.Kedah));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==6)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.Perlis));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==7)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.Pulau_Pinang));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==8)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.Perak));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==9)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.Kelantan));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==10)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.Terengganu));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==11)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.Pahang));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==12)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.Sabah));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==13)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.Sarawak));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==14)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.W_P_Kuala_Lumpur));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==15)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.W_P_Labuan));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position==16)
                {
                    dataAdapter = new ArrayAdapter<>(RegisterService.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.W_P_Putrajaya));
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                area.setAdapter(dataAdapter);

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {


            }
        });




        SubmitData();

    }




    public Boolean validate()
    {
        boolean result=false;

        String businessname=editBusinessName.getText().toString();
        String servicetype=editServiceType.getSelectedItem().toString();
        String contactnum=editContactNumber.getText().toString();
        String email=editEmail.getText().toString();
        String password=editPassword.getText().toString();


        if(businessname.isEmpty()||servicetype.equals("None")||contactnum.isEmpty()||email.isEmpty()||password.isEmpty())
        {
            String show="is empty";
            if(businessname.isEmpty())
            {
                String tempstring=" business name ";
                show=tempstring+show;
            }
            if(servicetype.equals("None"))
            {
                String tempstring=" service type ";
                show=tempstring+show;
            }
            if(contactnum.isEmpty())
            {
                String tempstring=" contact number ";
                show=tempstring+show;
            }
            if(email.isEmpty())
            {
                String tempstring=" email ";
                show=tempstring+show;
            }
            if(password.isEmpty())
            {
                String tempstring=" password ";
                show=tempstring+show;
            }
            Toast.makeText(RegisterService.this, show, Toast.LENGTH_SHORT).show();
        }
        else
        {
            result=true;
        }

        return result;
    }

    public void SubmitData()
    {
        btnSubmitData.setOnClickListener(
                (view)->{
                    if(validate()) {
                        boolean isInserted = myDb.insertDataService(editBusinessName.getText().toString(), editServiceType.getSelectedItem().toString(), editContactNumber.getText().toString(), editEmail.getText().toString(), editPassword.getText().toString());
                        if (isInserted)
                            Toast.makeText(RegisterService.this, "Register Successful, Please Login", Toast.LENGTH_SHORT).show();
                        else
                            Toast.makeText(RegisterService.this, "Register Not Successful", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(RegisterService.this, LoginService.class);
                        startActivity(intent);
                    }
                }
        );
    }

}